var React=require('react');
var ReactDOM=require('react-dom');

module.exports=React.createClass({
    render:function(){
        return (
            <header className="header">
                <h1>todos</h1>
                <input type="text" className="new-todo" placeholder="有什么事情需要去做？" />
            </header>
        )
    }
});
