var React=require('react');

module.exports=React.createClass({
    render:function(){
        return (
            <section className="main">
                <input type="checkbox" className="toggle-all" />
                <ul className="todo-list">
                  <li>
                    <div className="view">
                      <input type="checkbox" className="toggle" />
                      <label htmlFor>sad</label>
                      <button className="destroy" />
                    </div>
                    <input type="text" className="edit" />
                  </li>
                </ul>
          </section>
        )
    }
});
