var React=require('react');
var ReactDOM=require('react-dom');
var TODOApp=require('./APP.js');

var mianCom=ReactDOM.render(<TODOApp/>,document.getElementById('app'));
