var React=require('react');
var ReactDOM=require('react-dom');
var AppHeader=require('./AppHeader.js');
var AppMain=require('./AppMain.js');
var AppFooter=require('./AppFooter.js');
module.exports=React.createClass({
    getInitialState:()=>{
        var todoItems=[{
            title:'sad',
            state:false,
        },{
            title:'good',
            state:false,
        }]
        return {
            todoItems:todoItems,
        }
    },
    render:()=>{
        return (
            <div>
                <AppHeader/>
                <AppMain/>
                <AppFooter/>
            </div>
        )
    }
});
