var React=require('react');
var ReactDOM=require('react-dom');

React.createClass({
    render:function(){
        return (
            
        )
    }
});
