var React=require('react');

module.exports=React.createClass({
    render:function(){
        return (
            <footer className="footer">
                <span className="todo-count">
                  <strong>1</strong>
                  <span />
                  <span>item</span>
                  <span>left</span>
                </span>
                <ul className="filters">
                  <li><a href className="selected">All</a></li>
                  <li><a href>Active</a></li>
                  <li><a href>Completed</a></li>
                </ul>
          </footer>
        )
    }
});
